package App;

import View.TPBankExe;

public class App {
    public static void main(String[] args) {
        TPBankExe exe = new TPBankExe();
        exe.run();
    }
}
