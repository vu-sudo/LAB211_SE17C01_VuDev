package Controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class FunctionsProgram {
    private final ArrayList<Integer> integerArrayList = new ArrayList<>();
    public static  final Scanner scan = new Scanner(System.in);
    BubbleSort bubbleSort = new BubbleSort();
    QuickSort quickSort = new QuickSort();

    public void generateArray() {
        integerArrayList.clear();
        int number = getNumber();
        Integer[] list = randomValue(number);
        integerArrayList.addAll(Arrays.asList(list));
        displayArray();
    }
    public ArrayList<Integer> returnArray() {
        return integerArrayList;
    }
    public Integer[] randomValue(int number) {
        Integer[] list = new Integer[number];
        for (int i = 0; i < list.length; i++) {
            list[i] = (int) (Math.random()*100);
        }
        return list;
    }
    public void displayArray() {
        System.out.println("YOUR ARRAY IS: <length: "+integerArrayList.size()+">");
        System.out.println(integerArrayList);
        System.out.println();
    }
    public Integer getNumber() {
        int number = -1;

      do {
          try{
              System.out.println("Enter a positive number");
              number = Integer.parseInt(scan.nextLine());
          } catch (NumberFormatException e) {
              System.err.println("Enter failed, pls enter again!");
          }
      } while (number < 0);
        return  number;
    }
    public void executeBubleSort() {
        bubbleSort.bubbleSortFunction(integerArrayList);
    }
    public void executeQuickSort() {
        quickSort.quickSortFunction(integerArrayList, 0, integerArrayList.size() - 1);
    }
}
