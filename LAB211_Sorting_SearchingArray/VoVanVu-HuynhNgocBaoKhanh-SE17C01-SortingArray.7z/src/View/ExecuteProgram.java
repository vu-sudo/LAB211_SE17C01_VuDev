package View;

import Controller.FunctionsProgram;

import java.util.Scanner;

public class ExecuteProgram  extends Menu{
    FunctionsProgram service = new FunctionsProgram();
    private final Scanner scan = new Scanner(System.in);
    static String[] MenuOption = {
            "Generate Array.",
            "Bubble Sort.",
            "Quick Sort.",
            "EXIT"
    };
    public ExecuteProgram() {
        super("BUBBLE SORT AND QUICK SORT", MenuOption);
    }
    public void waitForPressAnyKey () {
        System.out.println("Press any key to continue...");
        scan.nextLine();
        System.out.println("\n".repeat(100));
    }
    @Override
    public void execute(int number) {
        switch (number) {
            case 1:
                service.generateArray();
                waitForPressAnyKey();
                break;
            case 2:
               if(service.returnArray().isEmpty()) {
                   System.out.println("Your number list is EMPTY!, can't execute this function!");
                   waitForPressAnyKey();
                   break;
               } else {
                   System.out.println("BEFORE SORTING ARRAY:");
                   service.displayArray();
                   System.out.println("AFTER SORTING ARRAY:");
                   service.executeBubleSort();
                   service.displayArray();
               }
                waitForPressAnyKey();
                break;
            case 3:
                if(service.returnArray().isEmpty()) {
                    System.out.println("Your number list is EMPTY!, can't execute this function!");
                    waitForPressAnyKey();
                    break;
                } else {
                    System.out.println("BEFORE SORTING ARRAY:");
                    service.displayArray();
                    System.out.println("AFTER SORTING ARRAY:");
                    service.executeQuickSort();
                    service.displayArray();
                }
                waitForPressAnyKey();
                break;
            case 4:
                System.out.println("EXITED PROGRAM!");
            default:
                System.exit(0);
        }
    }
}
