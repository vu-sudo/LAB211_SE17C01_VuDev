/**
 * 
 */
/**
 * @author ADMIN
 *
 */
module slot6 {
}