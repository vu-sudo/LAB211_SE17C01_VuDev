package App;

import View.FileProcessingView;

public class App {
    public static void main(String[] args) throws Exception {
        FileProcessingView fileProcessingView = new FileProcessingView();
        fileProcessingView.run();
    }
}
